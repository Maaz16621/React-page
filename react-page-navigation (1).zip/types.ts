
export interface Page {
  id: string;
  name: string;
}

export interface ContextMenuState {
  pageId: string;
  x: number;
  y: number;
}
